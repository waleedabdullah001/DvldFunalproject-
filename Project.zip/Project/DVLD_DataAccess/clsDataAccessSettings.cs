﻿using System;

namespace DVLD_DataAccess
{
    static class clsDataAccessSettings
    {
        public static string ConnectionString = "Server=.;Database=DVLD;User Id= Shadow;Password=waleed77;";


    }
}
